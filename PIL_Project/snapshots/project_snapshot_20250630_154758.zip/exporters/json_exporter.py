# pil_meta/exporters/json_exporter.py
"""
Entity Graph Exporter (exporters)

Exports the entity graph to a timestamped JSON file for downstream tooling or archival.
"""

import json
from datetime import datetime
from pathlib import Path

def export_entity_graph(graph: dict, output_dir: str) -> None:
    """
    Export the entity graph to a timestamped JSON file.

    @tags: ["export", "graph"]
    @status: "stable"
    @visibility: "internal"

    Args:
        graph (dict): The entity graph (fqname → node).
        output_dir (str): Target directory for output.
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outfile = Path(output_dir) / f"entity_graph_{timestamp}.json"
    with open(outfile, "w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2, ensure_ascii=False)
    print(f"✅ Exported entity graph → {outfile}")
