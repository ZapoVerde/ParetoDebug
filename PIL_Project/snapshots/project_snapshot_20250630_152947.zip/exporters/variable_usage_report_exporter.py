# pil_meta/exporters/variable_usage_report_exporter.py
"""
Variable Usage Reporter (exporters)

Exports a Markdown report summarizing variable usage across modules.
This is derived from the usage map and shows which variables are used
by which symbols, aiding visibility and dependency tracing.
"""

from pathlib import Path

def export_variable_usage_markdown(usage_map: dict, output_path: str) -> None:
    """
    Export the variable usage summary to a Markdown file.

    @tags: ["export", "variables", "usage"]
    @status: "stable"
    @visibility: "public"

    Args:
        usage_map (dict): Usage summary from build_usage_map().
        output_path (str): Path to write the Markdown output to.
    """
    lines = ["# Variable Usage Report\n"]
    for varname, usage in sorted(usage_map.get("variable_usage", {}).items()):
        lines.append(f"\n## `{varname}`")
        for user in usage:
            lines.append(f"- `{user}`")
    Path(output_path).write_text("\n".join(lines), encoding="utf-8")
    print(f"✅ Exported variable usage markdown → {output_path}")
