# pil_meta/exporters/vault_index_exporter.py
"""
Vault Index Exporter (exporters)

Creates a master `index.md` for Obsidian vault navigation.
Groups all known exported entities by type with clickable links.
Intended for top-level visibility across exported Markdown symbols.
"""

from pathlib import Path

def export_vault_index(graph: dict, output_dir: str) -> None:
    """
    Export a Markdown index listing all symbols in the vault, grouped by type.

    @tags: ["export", "vault", "index"]
    @status: "stable"
    @visibility: "public"

    Args:
        graph (dict): Entity graph containing all symbols.
        output_dir (str): Output directory where `index.md` will be created.
    """
    index_lines = ["# Symbol Index\n"]
    grouped = {}

    for node in graph.values():
        if node.get("visibility") == "internal":
            continue
        typ = node.get("type", "misc")
        grouped.setdefault(typ, []).append(node)

    for typ in sorted(grouped):
        index_lines.append(f"\n## {typ.capitalize()}s")
        for node in sorted(grouped[typ], key=lambda x: x.get("fqname", "")):
            name = node.get("name") or node.get("fqname")
            filename = name.replace("/", "_").replace(".", "_") + ".md"
            subdir = typ + "s"
            index_lines.append(f"- [{name}]({subdir}/{filename})")

    outfile = Path(output_dir) / "index.md"
    outfile.write_text("\n".join(index_lines), encoding="utf-8")
    print(f"✅ Exported vault index → {outfile}")
