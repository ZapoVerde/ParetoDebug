# pil_meta/pipeline.py
"""
Main orchestration pipeline for the PIL meta-engine.
Fully config-driven: scans only what is listed in pilconfig.json: scan_dirs.
No hardcoded subfolder logic. No double-walking. No missed test/scripts folders.
"""

import sys
import traceback
import os
from pathlib import Path
from datetime import datetime

from pil_meta.loaders.config_loader import load_config
from pil_meta.loaders.asset_loader import load_asset_symbols
from pil_meta.loaders.code_loader import load_code_symbols
from pil_meta.loaders.markdown_loader import load_markdown_entries

from pil_meta.builders.entity_graph_builder import build_entity_graph
from pil_meta.builders.linkage_builder import inject_call_links
from pil_meta.builders.usage_map_builder import build_usage_map

from pil_meta.exporters.json_exporter import export_entity_graph
from pil_meta.exporters.usage_map_exporter import export_usage_map
from pil_meta.exporters.markdown_vault_exporter import export_markdown_vault
from pil_meta.exporters.md_exporter import export_entity_markdown
from pil_meta.exporters.vault_index_exporter import export_vault_index
from pil_meta.exporters.variable_usage_report_exporter import export_variable_usage_markdown

from pil_meta.utils.exceptions_reporter_utils import generate_exception_report
from pil_meta.utils.snapshot_utils import take_project_snapshot
from pil_meta.utils.export_cleanup_utils import clean_exports_dir

def run_pipeline(config_path="pilconfig.json"):
    """
    Orchestrates the full metadata pipeline:
    - Loads config
    - Scans code and asset symbols from exactly the folders in scan_dirs
    - Builds and links entity graph
    - Cleans exports directory
    - Writes all exports (JSON, usage map, Markdown vault)
    - Runs governance/exception report
    - Takes project snapshot

    Args:
        config_path (str): Path to pilconfig.json
    """
    try:
        config = load_config(config_path)
        project_name = Path(config["project_root"]).resolve().name
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        scan_dirs = [str(Path(d).resolve()) for d in config.get("scan_dirs", [config["project_root"]])]
        all_seen_folders = set()
        py_files = []

        print("\n🔍 Code folder scan (from pilconfig.json scan_dirs):")
        for scan_root in scan_dirs:
            scan_path = Path(scan_root)
            if not scan_path.exists():
                print(f"❌ Skipping: scan_dir '{scan_root}' does not exist")
                continue
            print(f"✅ Scanning: {scan_root}")
            for folder, subdirs, files in os.walk(scan_path):
                folder_path = str(Path(folder).resolve())
                # Deduplicate folders
                if folder_path in all_seen_folders:
                    continue
                all_seen_folders.add(folder_path)
                # Skip __pycache__ and hidden/system dirs
                if "__pycache__" in folder_path.split(os.sep):
                    print(f"🚫 Skipping ignored folder: {folder_path}")
                    subdirs[:] = []  # Don't descend further
                    continue
                for f in files:
                    if f.endswith(".py"):
                        py_files.append(str(Path(folder_path) / f))

        py_files = list(set(py_files))  # Deduplicate files

        print(f"\n📁 Total folders scanned (excluding ignored): {len(all_seen_folders)}")
        print(f"📋 Total Python files found: {len(py_files)}")

        # --- Write full scan report ---
        scan_report_path = Path(config["output_dir"]) / f"scan_report_{timestamp}.txt"
        with open(scan_report_path, "w", encoding="utf-8") as f:
            for pyfile in sorted(py_files):
                f.write(f"{pyfile}\n")
        print(f"\n📋 Scan report written: {scan_report_path} ({len(py_files)} files listed)")

        # --- Extract symbols from code files ---
        code_symbols = []
        for pyfile in py_files:
            code_symbols.extend(load_code_symbols(str(pyfile), str(config["project_root"])))

        # --- Load asset symbols as before ---
        asset_symbols = load_asset_symbols(config)

        print("\n🔍 Scanning summary:")
        print(f"   ├─ Code symbols: {len(code_symbols)}")
        print(f"   ├─ Asset files: {len(asset_symbols)}")
        print(f"   └─ Project root: {config['project_root']}")

        entities = code_symbols + asset_symbols
        entity_graph = build_entity_graph(entities)
        entity_graph = inject_call_links(entity_graph, str(config["project_root"]))

        print("\n🧠 Graph construction:")
        print(f"   ├─ Total nodes: {len(entity_graph)}")
        print("   └─ Linkages injected")

        clean_exports_dir(config["output_dir"])

        graph_paths = export_entity_graph(entity_graph, config["output_dir"], project_name, timestamp)
        usage_paths = export_usage_map(build_usage_map(entity_graph), config["output_dir"], project_name, timestamp)
        vault_files = export_markdown_vault(entity_graph, config["vault_dir"], project_name, timestamp)
        index_path = export_vault_index(entity_graph, config["vault_dir"], project_name, timestamp)
        variable_report_path = export_variable_usage_markdown(
            build_usage_map(entity_graph),
            str(Path(config["output_dir"]) / "variable_usage.md"),
            project_name,
            timestamp
        )

        print("\n📤 Exports written:")
        print(f"   ├─ Entity graph → {graph_paths['timestamped']}")
        print(f"   ├─ Usage map → {usage_paths['timestamped']}")
        print(f"   ├─ Vault files → {len(vault_files)} Markdown files")
        print(f"   ├─ Vault index → {index_path}")
        print(f"   └─ Variable usage → {variable_report_path}")

        try:
            generate_exception_report(entity_graph, config["output_dir"], project_name, timestamp)
        except Exception as e:
            print(f"❌ Failed to generate exceptions report: {e}")

        print("\n📎 Governance:")
        print(f"   ├─ Exceptions (latest) → {Path(config['output_dir']) / f'function_map_exceptions_{timestamp}.json'}")
        print(f"   └─ Usage map (timestamped) → {usage_paths['timestamped']}")

        journal_entries = load_markdown_entries(config["journal_path"])
        print(f"\n📓 Journal entries loaded: {len(journal_entries)}")

        missing_docstrings = sum(1 for n in entity_graph.values() if not n.get("docstring_present"))
        orphaned = sum(1 for n in entity_graph.values() if n.get("is_orphaned"))

        print("\n📊 Project health:")
        print(f"   ├─ Missing docstrings: {missing_docstrings}")
        print(f"   └─ Orphaned entities: {orphaned}")

        print("\n✅ Metadata pipeline complete.")

        snapshot_path = take_project_snapshot(
            config,
            entity_graph_path=graph_paths["timestamped"]
        )
        from zipfile import ZipFile
        with ZipFile(snapshot_path, 'r') as zipf:
            file_count = len(zipf.infolist())
        print(f"📦 Created snapshot with {file_count} files → {snapshot_path}")

    except Exception:
        print("\n❌ Pipeline failed. Full traceback below:")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    run_pipeline()
