# pil_meta/pipeline.py
"""
Main orchestration pipeline for the PIL meta-engine.
Fully config-driven: scans only what is listed in pilconfig.json: scan_dirs.
Indented folder scan report, no duplicates, all governance logic preserved.
"""

import sys
import traceback
import os
from pathlib import Path
from datetime import datetime
from zipfile import ZipFile

from pil_meta.loaders.config_loader import load_config
from pil_meta.loaders.asset_loader import load_asset_symbols
from pil_meta.loaders.code_loader import load_code_symbols
from pil_meta.loaders.markdown_loader import load_markdown_entries

from pil_meta.builders.entity_graph_builder import build_entity_graph
from pil_meta.builders.linkage_builder import inject_call_links
from pil_meta.builders.usage_map_builder import build_usage_map

from pil_meta.exporters.json_exporter import export_entity_graph
from pil_meta.exporters.usage_map_exporter import export_usage_map
from pil_meta.exporters.markdown_vault_exporter import export_markdown_vault
from pil_meta.exporters.md_exporter import export_entity_markdown
from pil_meta.exporters.vault_index_exporter import export_vault_index
from pil_meta.exporters.variable_usage_report_exporter import export_variable_usage_markdown

from pil_meta.utils.exceptions_reporter_utils import generate_exception_report
from pil_meta.utils.snapshot_utils import take_project_snapshot
from pil_meta.utils.export_cleanup_utils import clean_exports_dir

def run_pipeline(config_path="pilconfig.json"):
    """
    Orchestrates the full metadata pipeline with quiet, tree-style scan summary.
    - Loads config
    - Scans code and asset symbols from exactly the folders in scan_dirs
    - Prints a single folder tree summary at the end (no file spamming)
    - Builds and links entity graph
    - Cleans exports directory
    - Writes all exports (JSON, usage map, Markdown vault)
    - Runs governance/exception report
    - Takes project snapshot

    Args:
        config_path (str): Path to pilconfig.json
    """
    try:
        config = load_config(config_path)
        project_name = Path(config["project_root"]).resolve().name
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        scan_roots = [str(Path(d).resolve()) for d in config.get("scan_dirs", [config["project_root"]])]
        all_seen_folders = set()
        py_files = []
        file_roots = []

        # --- TREE-STYLE FOLDER SCAN ---
        folder_tree = {}

        def get_parent_dir(path):
            return str(Path(path).parent)

        for scan_root in scan_roots:
            scan_path = Path(scan_root)
            if not scan_path.exists():
                folder_tree[scan_root] = {
                    "parent": None,
                    "children": [],
                    "num_py": 0,
                    "ignored": False,
                    "skipped": True,
                }
                continue
            for folder, subdirs, files in os.walk(scan_path):
                folder_path = str(Path(folder).resolve())
                if folder_path in all_seen_folders:
                    continue
                all_seen_folders.add(folder_path)
                parent = get_parent_dir(folder_path)
                if folder_path not in folder_tree:
                    folder_tree[folder_path] = {
                        "parent": parent if folder_path != scan_root else None,
                        "children": [],
                        "num_py": 0,
                        "ignored": False,
                        "skipped": False,
                    }
                if "__pycache__" in folder_path.split(os.sep):
                    folder_tree[folder_path]["ignored"] = True
                    subdirs[:] = []
                    continue
                py_count = 0
                for f in files:
                    if f.endswith(".py"):
                        py_count += 1
                        py_files.append(str(Path(folder_path) / f))
                        file_roots.append(str(scan_path))
                folder_tree[folder_path]["num_py"] += py_count
                # Add children for parent
                if parent and parent in folder_tree:
                    if folder_path not in folder_tree[parent]["children"]:
                        folder_tree[parent]["children"].append(folder_path)

        # --- FOLDER TREE PRINTER ---
        def print_folder_summary(tree, scan_roots):
            def _print_node(folder, depth=0):
                node = tree[folder]
                indent = "    " * depth
                short_name = Path(folder).name
                line = f"{indent}{short_name}/"
                if node["skipped"]:
                    line += " [SKIPPED: not found]"
                elif node["ignored"]:
                    line += " [IGNORED]"
                else:
                    line += f" ({node['num_py']} .py)"
                print(line)
                for child in sorted(node["children"], key=lambda c: Path(c).name):
                    _print_node(child, depth+1)
            print("\n========== Folder-by-Folder Scan Summary ==========")
            for root in scan_roots:
                if root in tree:
                    _print_node(root)

        print_folder_summary(folder_tree, scan_roots)
        print(f"\n📁 Total folders scanned (excluding ignored): {len(all_seen_folders)}")
        print(f"📋 Total Python files found: {len(py_files)}")

        # --- Write tree-style scan report to file ---
        scan_report_path = Path(config["output_dir"]) / f"scan_report_{timestamp}.txt"
        with open(scan_report_path, "w", encoding="utf-8") as f:
            def _write_node(folder, depth=0):
                node = folder_tree[folder]
                indent = "    " * depth
                short_name = Path(folder).name
                line = f"{indent}{short_name}/"
                if node["skipped"]:
                    line += " [SKIPPED: not found]"
                elif node["ignored"]:
                    line += " [IGNORED]"
                else:
                    line += f" ({node['num_py']} .py)"
                f.write(line + "\n")
                for child in sorted(node["children"], key=lambda c: Path(c).name):
                    _write_node(child, depth+1)
            for root in scan_roots:
                if root in folder_tree:
                    _write_node(root)
            f.write(f"\nTotal folders scanned (excluding ignored): {len(all_seen_folders)}\n")
            f.write(f"Total Python files found: {len(py_files)}\n")

        print(f"\n📋 Scan report written: {scan_report_path} ({len(py_files)} files listed)")

        # --- Extract symbols from code files (use correct root for each) ---
        code_symbols = []
        for pyfile, file_root in zip(py_files, file_roots):
            code_symbols.extend(load_code_symbols(pyfile, file_root))

        # --- Load asset symbols as before ---
        asset_symbols = load_asset_symbols(config)

        print("\n🔍 Scanning summary:")
        print(f"   ├─ Code symbols: {len(code_symbols)}")
        print(f"   ├─ Asset files: {len(asset_symbols)}")
        print(f"   └─ Project root: {config['project_root']}")

        entities = code_symbols + asset_symbols
        entity_graph = build_entity_graph(entities)
        entity_graph = inject_call_links(entity_graph, str(config["project_root"]))

        print("\n🧠 Graph construction:")
        print(f"   ├─ Total nodes: {len(entity_graph)}")
        print("   └─ Linkages injected")

        clean_exports_dir(config["output_dir"])

        graph_paths = export_entity_graph(entity_graph, config["output_dir"], project_name, timestamp)
        usage_paths = export_usage_map(build_usage_map(entity_graph), config["output_dir"], project_name, timestamp)
        vault_files = export_markdown_vault(entity_graph, config["vault_dir"], project_name, timestamp)
        index_path = export_vault_index(entity_graph, config["vault_dir"], project_name, timestamp)
        variable_report_path = export_variable_usage_markdown(
            build_usage_map(entity_graph),
            str(Path(config["output_dir"]) / "variable_usage.md"),
            project_name,
            timestamp
        )

        print("\n📤 Exports written:")
        print(f"   ├─ Entity graph → {graph_paths['timestamped']}")
        print(f"   ├─ Usage map → {usage_paths['timestamped']}")
        print(f"   ├─ Vault files → {len(vault_files)} Markdown files")
        print(f"   ├─ Vault index → {index_path}")
        print(f"   └─ Variable usage → {variable_report_path}")

        try:
            generate_exception_report(entity_graph, config["output_dir"], project_name, timestamp)
        except Exception as e:
            print(f"❌ Failed to generate exceptions report: {e}")

        print("\n📎 Governance:")
        print(f"   ├─ Exceptions (latest) → {Path(config['output_dir']) / f'function_map_exceptions_{timestamp}.json'}")
        print(f"   └─ Usage map (timestamped) → {usage_paths['timestamped']}")

        journal_entries = load_markdown_entries(config["journal_path"])
        print(f"\n📓 Journal entries loaded: {len(journal_entries)}")

        missing_docstrings = sum(1 for n in entity_graph.values() if not n.get("docstring_present"))
        orphaned = sum(1 for n in entity_graph.values() if n.get("is_orphaned"))

        print("\n📊 Project health:")
        print(f"   ├─ Missing docstrings: {missing_docstrings}")
        print(f"   └─ Orphaned entities: {orphaned}")

        print("\n✅ Metadata pipeline complete.")

        snapshot_path = take_project_snapshot(
            config,
            entity_graph_path=graph_paths["timestamped"]
        )
        with ZipFile(snapshot_path, 'r') as zipf:
            file_count = len(zipf.infolist())
        print(f"📦 Created snapshot with {file_count} files → {snapshot_path}")

    except Exception:
        print("\n❌ Pipeline failed. Full traceback below:")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    run_pipeline()
