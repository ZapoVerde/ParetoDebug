# pil_meta/exporters/usage_map_exporter.py

from pathlib import Path
import json
from datetime import datetime

def export_usage_map(usage_map: dict, output_dir: str) -> dict:
    """
    Export the usage map to both a timestamped and stable JSON file.

    @tags: ["export", "usage"]
    @status: "stable"
    @visibility: "public"

    Args:
        usage_map (dict): Usage summary dictionary.
        output_dir (str): Directory to write the JSON file into.

    Returns:
        dict: Paths of both timestamped and stable filenames
    """
    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    for old_file in outdir.glob("usage_map_*.json"):
        old_file.unlink()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamped = outdir / f"usage_map_{timestamp}.json"
    stable = outdir / "usage_map.json"

    with open(timestamped, "w", encoding="utf-8") as f:
        json.dump(usage_map, f, indent=2, ensure_ascii=False)

    stable.write_text(timestamped.read_text(), encoding="utf-8")

    return {"timestamped": str(timestamped), "stable": str(stable)}