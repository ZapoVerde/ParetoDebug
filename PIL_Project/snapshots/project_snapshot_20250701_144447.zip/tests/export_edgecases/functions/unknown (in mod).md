# unknown (in mod)
> **Fully qualified name:** `mod.empty`

**Type:** function
**Module:** mod
**Status:** n/a
**Visibility:** n/a
**Tags:** 
**Deprecated:** ❌

---

## Description


## Full Docstring
```

```

## Links
None

---
