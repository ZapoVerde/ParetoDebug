# pil_meta/exporters/json_exporter.py
"""
Entity Graph Exporter (exporters)

Exports the entity graph to a timestamped JSON file for downstream tooling or archival.
"""

import json
from datetime import datetime
from pathlib import Path

def export_entity_graph(graph: dict, output_dir: str) -> None:
    """
    Export the full entity graph to a timestamped JSON file.

    @tags: ["export", "graph"]
    @status: "stable"
    @visibility: "public"

    Args:
        graph (dict): Entity graph keyed by fqname
        output_dir (str): Directory to write output
    """
    from datetime import datetime
    from pathlib import Path
    import json

    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    for old_file in outdir.glob("entity_graph_*.json"):
        old_file.unlink()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outfile = outdir / f"entity_graph_{timestamp}.json"

    with open(outfile, "w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2)

    print(f"✅ Exported entity graph → {outfile}")
