# pil_meta/exporters/json_exporter.py
"""
Entity Graph Exporter (exporters)

Exports the entity graph to a timestamped JSON file for downstream tooling or archival.
"""

import json
from datetime import datetime
from pathlib import Path

def export_entity_graph(graph: dict, output_dir: str) -> dict:
    """
    Export the full entity graph to both a timestamped and stable JSON file.

    @tags: ["export", "graph"]
    @status: "stable"
    @visibility: "public"

    Args:
        graph (dict): Entity graph keyed by fqname
        output_dir (str): Directory to write output

    Returns:
        dict: Paths of both timestamped and stable filenames
    """
    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    for old_file in outdir.glob("entity_graph_*.json"):
        old_file.unlink()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamped = outdir / f"entity_graph_{timestamp}.json"
    stable = outdir / "entity_graph.json"

    with open(timestamped, "w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2)

    stable.write_text(timestamped.read_text(), encoding="utf-8")

    return {"timestamped": str(timestamped), "stable": str(stable)}
