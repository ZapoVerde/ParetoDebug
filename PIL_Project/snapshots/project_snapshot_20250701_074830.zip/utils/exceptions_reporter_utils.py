# pil_meta/utils/exceptions_reporter_utils.py
"""
Project health analysis and governance exception reporting.

Delegates validation and enrichment to dedicated modules. Coordinates:
- Governance rule execution
- Usage graph export
- Summary reporting

Governance logic lives in governance_validator.py
Usage mapping lives in usage_map_builder.py

@tags: ["exceptions", "report", "governance"]
@status: "stable"
@visibility: "public"
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Optional
from pil_meta.validators.governance_validator import validate_governance_rules


def generate_exception_report(
    graph: dict,
    output_dir: str,
    project_name: str = "project",
    timestamp: Optional[str] = None
) -> dict:
    """Generates governance exception reports with timestamped filenames and embedded metadata.
    The output JSON file includes top-level 'timestamp' and 'project_name' fields for standards compliance.

    @tags: ["governance", "report", "exceptions"]
    @status: "stable"
    @visibility: "public"

    Args:
        graph (dict): Entity graph keyed by fqname.
        output_dir (str): Where to write JSON files.
        project_name (str): Project name for metadata and filename.
        timestamp (str): Optional timestamp (YYYYMMDD_HHMMSS). If None, current time is used.

    Returns:
        dict: Summary stats for key issue types.
    """
    exceptions, issue_counts = validate_governance_rules(graph)

    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    # Clean up old exception reports only (usage map export is now handled separately)
    for old in outdir.glob("function_map_exceptions_*.json"):
        old.unlink()

    ts = timestamp or datetime.now().strftime("%Y%m%d_%H%M%S")
    exception_path = outdir / f"function_map_exceptions_{ts}.json"

    wrapper = {
        "timestamp": ts,
        "project_name": project_name,
        "exceptions": exceptions
    }

    with exception_path.open("w", encoding="utf-8") as f:
        json.dump(wrapper, f, indent=2)

    print(f"\n🚨 Exceptions report written → {exception_path}")

    return {
        "missing_docstrings": issue_counts.get("missing_docstring", 0),
        "untested": issue_counts.get("missing_test", 0),
        "orphaned": issue_counts.get("orphaned", 0),
        "missing_tags": issue_counts.get("missing_tags", 0),
        "ignored_functions_used": issue_counts.get("invalid_ignore_usage", 0)
    }
