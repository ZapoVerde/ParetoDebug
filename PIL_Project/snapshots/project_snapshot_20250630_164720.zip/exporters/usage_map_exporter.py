# pil_meta/exporters/usage_map_exporter.py

from pathlib import Path
import json

def export_usage_map(usage_map: dict, output_dir: str) -> None:
    """
    Export the usage map to a timestamped JSON file.

    @tags: ["export", "usage"]
    @status: "stable"
    @visibility: "public"

    Args:
        usage_map (dict): Usage summary dictionary.
        output_dir (str): Directory to write the JSON file into.
    """
    from datetime import datetime
    from pathlib import Path
    import json

    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    for old_file in outdir.glob("usage_map_*.json"):
        old_file.unlink()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outfile = outdir / f"usage_map_{timestamp}.json"

    with open(outfile, "w", encoding="utf-8") as f:
        json.dump(usage_map, f, indent=2, ensure_ascii=False)

    print(f"✅ Exported usage map → {outfile}")
